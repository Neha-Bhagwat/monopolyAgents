import argparse
from dataclasses import replace
from pathlib import Path

from .bargaining import NashTrading, TitForTatTrading
from .advanced_bargaining import MinimaxRegretTrading, ZeuthenTrading, minimax_regret_choice
from .board import BOARD
from .bots import (AcceptingBot, SimpleBot, adaptive_bot, baseline_bot, cooperator_bot,
                   hard_bargainer_bot, reciprocator_bot, risk_averse_bot)
from .engine import Game
from .experiments import PILOT_STRATEGIES, STRATEGIES, print_summary, replay, run_pilot
from .models import GameView, Offer, Reply
from .valuation import landing_probabilities, score_trade


def print_game(game: Game, show_trades: bool = False) -> None:
    result = game.play()
    reasons = {"last_player": "last player standing", "turn_limit": "turn limit"}
    print(f"Seed {result.seed}: Player {result.winner + 1} won after {result.turns} turns.")
    print(f"End reason: {reasons[result.end_reason]}")
    for i, worth in enumerate(result.net_worth):
        status = " (bankrupt)" if result.bankrupt[i] else ""
        print(f"Player {i + 1}: ${worth:,}{status}")
    if show_trades:
        print(f"Trades proposed: {result.trades_proposed}. Trades accepted: {result.trades_accepted}.")
        for record in game.trade_history:
            print(f"Turn {record.turn} accepted trade:")
            print_offer(record.offer)


def print_offer(offer: Offer) -> None:
    def describe(properties: tuple[int, ...], cash: int) -> str:
        items = [BOARD[square].name for square in properties]
        if cash:
            items.append(f"${cash:,}")
        return " and ".join(items) or "nothing"

    for player, properties, cash in (
        (offer.proposer, offer.give_properties, offer.give_cash),
        (offer.recipient, offer.ask_properties, offer.ask_cash),
    ):
        print(f"  Player {player + 1} gives {describe(properties, cash)}.")


DEMO_OFFER = Offer(0, 1, give_properties=(5,), ask_properties=(3,), give_cash=25)


class TradeDemoBot(SimpleBot):
    """Makes the demo offer when the engine asks on the first turn."""

    def propose(self, view: GameView, player: int) -> Offer | None:
        if view.turns == 0 and player == DEMO_OFFER.proposer:
            return DEMO_OFFER
        return None


def set_up_demo_board(game: Game) -> None:
    game.players[0].position = 5
    game.owners[1] = 0
    game.owners[5] = 0
    for square in (3, 7, 9):
        game.owners[square] = 1


def print_trade() -> None:
    game = Game([TradeDemoBot(), AcceptingBot()], turn_limit=2, trace=print)
    set_up_demo_board(game)
    print("Trade demo: two turns from a prepared board.")
    result = game.play()
    if result.trades_accepted != 1:
        raise RuntimeError("The demo expected exactly one accepted trade.")

    print("After two turns:")
    for player, state in enumerate(game.players):
        properties = [BOARD[i].name for i, owner in enumerate(game.owners) if owner == player]
        print(f"Player {player + 1}: ${state.cash:,} and {', '.join(properties)}")


def print_valuation() -> None:
    game = Game([SimpleBot(), SimpleBot()])
    set_up_demo_board(game)
    game.turns = 109
    print("Valuation demo: same offer as the trade demo, with 40 future turns in total.")
    print("Player 1 offers Oriental Avenue and $25 for Baltic Avenue.")
    print("\nEstimated chance of ending a turn on each property:")
    for square, probability in zip(BOARD, landing_probabilities()):
        if square.property is not None:
            print(f"  {square.name:23} {probability:6.2%}")

    for value in score_trade(game.view(), DEMO_OFFER):
        print(f"\nPlayer {value.player + 1}")
        if value.sets_gained:
            print(f"  Completes: {', '.join(value.sets_gained)}")
        print(f"  Cash change:            {value.cash_change:+.2f}")
        print(f"  Printed deed value:     {value.deed_change:+.2f}")
        print(f"  Estimated net rent:     {value.rent_change:+.2f}")
        print(f"  Future building rent:   {value.development_change:+.2f}")
        print(f"  Color-set bonus change: {value.set_bonus_change:+.2f}")
        print(f"  Estimated total ($):    {value.total:+.2f}")
    print("\nThe offer was scored only. No money or deeds moved.")


def print_bargaining_demo() -> None:
    game = Game([SimpleBot(), SimpleBot()])
    set_up_demo_board(game)
    game.turns = 109
    # Limited cash keeps this example focused on bargaining thresholds.
    for player in game.players:
        player.cash = 150
    view = game.view()
    offer = replace(DEMO_OFFER, give_cash=0, ask_cash=90)
    print("Bargaining demo: Player 2 is deciding on this offer.")
    print("Both players have $150, so neither can fund buildings after this offer.")
    print_offer(offer)
    proposer, recipient = score_trade(view, offer)
    print(f"Player 1's estimated gain is ${proposer.total:.2f}.")
    print(f"Player 2's estimated gain is ${recipient.total:.2f}.")

    reciprocator = TitForTatTrading()
    for name, strategy in (("Cooperator", NashTrading()), ("Reciprocator", reciprocator)):
        reply = strategy.respond(view, offer, 1)
        if reply is Reply.ACCEPT:
            print(f"{name} accepts.")
        elif isinstance(reply, Offer):
            print(f"{name} counters with:")
            print_offer(reply)
        else:
            print(f"{name} rejects.")

    print("\nNow suppose Player 1 previously sent an unfair offer.")
    reciprocator = TitForTatTrading()
    unfair = replace(DEMO_OFFER, give_cash=0, ask_cash=150)
    reciprocator.respond(view, unfair, 1)
    print(f"Reciprocator now wants at least ${reciprocator.minimum_gain(0)} in estimated gain.")
    reply = reciprocator.respond(view, offer, 1)
    if isinstance(reply, Offer):
        print("Reciprocator counters with:")
        print_offer(reply)
    elif reply is Reply.REJECT:
        print("Reciprocator rejects.")
    else:
        print("Reciprocator accepts.")
    print("This demo compares decisions. No cash or deeds move.")


def print_step6_demo() -> None:
    print("Step 6: prepared examples, not a full game. Use --step6-game for live play.")
    game = Game([adaptive_bot(), SimpleBot()])
    set_up_demo_board(game)
    game.turns = 109
    for player in game.players:
        player.cash = 150
    view = game.view()

    hard = ZeuthenTrading()
    opening = hard.propose(view, 0)
    print("\nHard-bargainer's preferred opening:")
    print_offer(opening)
    incoming = Offer(1, 0, (3,), (5,), give_cash=40)
    print("The other player counters with Baltic and $40 for Oriental.")
    reply = hard.respond(view, incoming, 2)
    print("Hard-bargainer's response:")
    print_offer(reply) if isinstance(reply, Offer) else print(reply.name)

    adaptive = game.bots[0].trading
    print("\nAdaptive's beliefs (easy, moderate, demanding):")
    print(tuple(round(p, 3) for p in adaptive.beliefs_for(1)))
    for attempt in range(2):
        offer = adaptive.propose(game.view(), 0)
        print(f"Prepared rejection {attempt + 1}, Adaptive offers:")
        print_offer(offer)
        # The prepared recipient is a nontrading bot. Actual engine feedback updates beliefs.
        game.negotiate(offer)
        print("Updated beliefs:", tuple(round(p, 3) for p in adaptive.beliefs_for(1)))
    print("Adaptive's next preferred offer after those replies:")
    print_offer(adaptive.propose(game.view(), 0))

    print("\nRisk-averse: a small illustrative payoff table, separate from the board.")
    names = ("No deal", "Firm", "Moderate", "Safe")
    payoffs = [(0, 0, 0), (100, 0, 0), (60, 60, 0), (40, 40, 40)]
    for name, row in zip(names, payoffs):
        print(f"{name:10} {row}")
    print("Columns mean easy, moderate, and demanding opponent assumptions.")
    print("Lowest worst regret:", names[minimax_regret_choice(payoffs)], "(regret 40).")
    print("Risk-averse's actual offer on the prepared Monopoly board:")
    offer = MinimaxRegretTrading().propose(view, 0)
    print_offer(offer) if offer is not None else print("No offer.")
    print("No deals were accepted in these prepared examples.")


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the simplified Monopoly demo.")
    parser.add_argument("--seed", type=int, help="Seed for a single full game (default 42).")
    demos = parser.add_mutually_exclusive_group()
    demos.add_argument("--trade-demo", action="store_true", help="Watch a scripted trade during play.")
    demos.add_argument("--valuation-demo", action="store_true", help="Score the scripted trade.")
    demos.add_argument("--baseline-game", action="store_true", help="Play four Baselines from Go.")
    demos.add_argument("--bargaining-game", action="store_true", help="Play both negotiators and two Baselines.")
    demos.add_argument("--bargaining-demo", action="store_true", help="Compare replies to an example offer.")
    demos.add_argument("--step6-demo", action="store_true", help="Explain all three new bargaining rules.")
    demos.add_argument("--step6-game", action="store_true", help="Play the three new negotiators and one Baseline.")
    demos.add_argument("--pilot", action="store_true", help="Run a controlled comparison (120 games by default).")
    demos.add_argument("--replay", type=Path, metavar="FOLDER", help="Replay a game from a pilot folder.")
    parser.add_argument("--output", type=Path, help="New pilot folder (default results/step5).")
    parser.add_argument("--game-id", help="Saved game ID to replay.")
    parser.add_argument("--seed-start", type=int, help="First pilot seed (default 0).")
    parser.add_argument("--seed-count", type=int, help="Number of pilot seeds (default 10); each plays all four seats.")
    parser.add_argument("--all-strategies", action="store_true", help="With --pilot, test all five bargaining rules plus no trade.")
    args = parser.parse_args()
    if args.replay and not args.game_id:
        parser.error("--replay requires --game-id")
    if args.game_id and not args.replay:
        parser.error("--game-id requires --replay")
    if args.output and not args.pilot:
        parser.error("--output requires --pilot")
    if args.all_strategies and not args.pilot:
        parser.error("--all-strategies requires --pilot")
    if (args.seed_start is not None or args.seed_count is not None) and not args.pilot:
        parser.error("--seed-start and --seed-count require --pilot")
    if args.seed is not None and (args.pilot or args.replay or args.trade_demo or
                                  args.valuation_demo or args.bargaining_demo or args.step6_demo):
        parser.error("--seed applies to single full games. Use --seed-start and --seed-count for a pilot.")
    seed = 42 if args.seed is None else args.seed
    if args.pilot:
        output = args.output or Path("results/step5")
        try:
            print_summary(run_pilot(output, seed_start=args.seed_start if args.seed_start is not None else 0,
                                    seed_count=args.seed_count if args.seed_count is not None else 10,
                                    strategies=STRATEGIES if args.all_strategies else PILOT_STRATEGIES))
        except (OSError, ValueError) as error:
            parser.exit(2, f"{error}\n")
        print(f"Saved results in {output.resolve()}")
    elif args.replay:
        try:
            replay(args.replay, args.game_id)
        except (OSError, ValueError) as error:
            parser.exit(2, f"{error}\n")
    elif args.trade_demo:
        print_trade()
    elif args.valuation_demo:
        print_valuation()
    elif args.bargaining_demo:
        print_bargaining_demo()
    elif args.step6_demo:
        print_step6_demo()
    elif args.step6_game:
        print("Players 1 to 4: Hard-bargainer, Adaptive, Risk-averse, Baseline.")
        bots = [hard_bargainer_bot(), adaptive_bot(), risk_averse_bot(), baseline_bot()]
        print_game(Game(bots, seed=seed), show_trades=True)
    elif args.bargaining_game:
        print("Players 1 to 4: Cooperator, Reciprocator, Baseline, Baseline.")
        bots = [cooperator_bot(), reciprocator_bot(), baseline_bot(), baseline_bot()]
        print_game(Game(bots, seed=seed), show_trades=True)
    elif args.baseline_game:
        print_game(Game([baseline_bot() for _ in range(4)], seed=seed), show_trades=True)
    else:
        print_game(Game([SimpleBot() for _ in range(4)], seed=seed))


if __name__ == "__main__":
    main()
