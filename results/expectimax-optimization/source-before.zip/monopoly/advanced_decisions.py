"""Bounded search decisions; MCTS and prospect theory remain future work."""

from dataclasses import replace

from .board import CHANCE, CHEST, GROUPS, Kind
from .engine import Game, Player
from .models import GameView, completed_sets
from .valuation import (BUILD_RESERVE, CAPITAL_HURDLE, DICE_TOTALS, SET_BONUS,
                        building_gain, landing_probabilities, purchase_gain)


class _Forecast(Game):
    """Private copy using engine landing/payment rules, without bots or RNG.

    Unowned purchases are deferred to the search's decision node. Only view,
    landing, payment, build-options and net-worth helpers are used, never play.
    """

    def __init__(self, view: GameView):
        self.players = [Player(p.cash, p.position, p.jailed, p.bankrupt) for p in view.players]
        self.owners = list(view.owners)
        self.buildings = list(view.buildings)
        self.active_player = view.active_player
        self.turns = view.turns
        self.turn_limit = view.turn_limit
        self.trace = None
        self.chance = list(CHANCE)
        self.chest = list(CHEST)

    def _land_on_property(self, player: int, square: int) -> None:
        if self.owners[square] is not None:
            super()._land_on_property(player, square)


def _buy(view: GameView, player: int, square: int) -> GameView:
    game = _Forecast(view)
    game.players[player].cash -= view.board[square].property.price
    game.owners[square] = player
    return game.view()


def _build(view: GameView, player: int, square: int) -> GameView:
    game = _Forecast(view)
    game.players[player].cash -= view.board[square].property.build_cost
    game.buildings[square] += 1
    return game.view()


class ExpectimaxDecisions:
    """Maximize estimated relative wealth over a bounded chance tree.

    Depth counts future individual player turns, not full rounds. Dice outcomes
    are exact; unknown cards are independent uniform draws from the fixed deck.
    Opponents use expected-value buy/build choices. Future trades are omitted.
    Leaves value current assets, stationary expected net rent, complete sets and
    liquidity. This is a heuristic planner, not a trained model or win oracle.
    """

    def __init__(self, depth: int = 2, max_nodes: int = 1000):
        if type(depth) is not int or not 1 <= depth <= 3:
            raise ValueError("Expectimax depth must be 1, 2, or 3 player turns.")
        if type(max_nodes) is not int or max_nodes < 1:
            raise ValueError("Expectimax max_nodes must be a positive integer.")
        self.depth = depth
        self.max_nodes = max_nodes

    @staticmethod
    def _can_buy(view: GameView, player: int, square: int) -> bool:
        prop = view.board[square].property
        return (not view.players[player].bankrupt and prop is not None
                and view.owners[square] is None
                and view.players[player].cash >= prop.price + 150)

    @staticmethod
    def _build_options(view: GameView, player: int) -> tuple[int, ...]:
        return tuple(square for square in _Forecast(view)._build_options(player)
                     if view.players[player].cash >=
                     view.board[square].property.build_cost + BUILD_RESERVE)

    def buy(self, view: GameView, player: int, square: int) -> bool:
        if not self._can_buy(view, player, square):
            return False
        # A purchase is followed by this turn's build opportunity in the engine.
        skip = self._finish_build(view, player, self.depth, [0])
        purchase = self._finish_build(_buy(view, player, square), player, self.depth, [0])
        return purchase > skip + 1e-9

    def build(self, view: GameView, player: int, legal: tuple[int, ...]) -> int | None:
        best, value = None, self._next_turn(view, player, self.depth, [0])
        for square in self._build_options(view, player):
            if square not in legal:
                continue
            candidate = self._next_turn(_build(view, player, square), player, self.depth, [0])
            if candidate > value + 1e-9:
                best, value = square, candidate
        return best

    def _next_turn(self, view: GameView, player: int, depth: int, budget: list[int]) -> float:
        survivors = [i for i, p in enumerate(view.players) if not p.bankrupt]
        if len(survivors) <= 1:
            return self._evaluate(view, player)
        active = (view.active_player + 1) % len(view.players)
        while active not in survivors:
            active = (active + 1) % len(view.players)
        return self._search(replace(view, active_player=active, turns=view.turns + 1),
                            player, depth, budget)

    def _search(self, view: GameView, player: int, depth: int, budget: list[int]) -> float:
        if (depth == 0 or view.turns >= view.turn_limit or view.players[player].bankrupt
                or sum(not p.bankrupt for p in view.players) <= 1
                or budget[0] >= self.max_nodes):
            return self._evaluate(view, player)
        budget[0] += 1
        return sum(probability * self._after_landing(outcome, player, depth - 1, budget, skipped)
                   for probability, outcome, skipped in self._outcomes(view))

    @staticmethod
    def _outcomes(view: GameView):
        """Yield (probability, state, skip-actions) for one future movement."""
        active = view.active_player
        if view.players[active].jailed:
            game = _Forecast(view)
            game.players[active].jailed = False
            yield 1.0, game.view(), True
            return
        for total, ways in DICE_TOTALS.items():
            position = (view.players[active].position + total) % len(view.board)
            kind = view.board[position].kind
            cards = CHANCE if kind is Kind.CHANCE else CHEST if kind is Kind.CHEST else (None,)
            for card in cards:
                game = _Forecast(view)
                if view.players[active].position + total >= len(view.board):
                    game.players[active].cash += 200
                game.players[active].position = position
                if kind is Kind.CHANCE:
                    game.chance = [card]
                elif kind is Kind.CHEST:
                    game.chest = [card]
                game._land(active)
                state = game.players[active]
                yield ways / (36 * len(cards)), game.view(), state.jailed or state.bankrupt

    def _after_landing(self, view: GameView, player: int, depth: int,
                       budget: list[int], skipped: bool) -> float:
        active = view.active_player
        if skipped or sum(not p.bankrupt for p in view.players) <= 1:
            return self._next_turn(view, player, depth, budget)
        square = view.players[active].position
        if self._can_buy(view, active, square):
            purchased = _buy(view, active, square)
            if active == player:
                return max(self._finish_build(view, player, depth, budget),
                           self._finish_build(purchased, player, depth, budget))
            if purchase_gain(view, active, square) > 0:
                view = purchased
        return self._finish_build(view, player, depth, budget)

    def _finish_build(self, view: GameView, player: int, depth: int, budget: list[int]) -> float:
        active = view.active_player
        options = self._build_options(view, active)
        if active == player:
            values = [self._next_turn(view, player, depth, budget)]
            values.extend(self._next_turn(_build(view, active, square), player, depth, budget)
                          for square in options)
            return max(values)
        best = max(options, key=lambda square: building_gain(view, square), default=None)
        if best is not None and building_gain(view, best) > 0:
            view = _build(view, active, best)
        return self._next_turn(view, player, depth, budget)

    @staticmethod
    def _evaluate(view: GameView, player: int) -> float:
        if view.players[player].bankrupt:
            return -100_000.0
        survivors = [i for i, p in enumerate(view.players) if not p.bankrupt]
        if len(survivors) == 1:
            return 100_000.0
        game = _Forecast(view)
        worth = [game.net_worth(i) for i in range(len(view.players))]
        if view.turns >= view.turn_limit:
            return worth[player] - max(worth[i] for i in survivors if i != player)
        remaining = max(0, view.turn_limit - view.turns)
        incomes = [0.0] * len(view.players)
        for square, chance in enumerate(landing_probabilities()):
            owner = view.owners[square]
            if owner is None:
                continue
            prop = view.board[square].property
            level = view.buildings[square]
            rent = prop.rents[level]
            if level == 0 and all(view.owners[i] == owner for i in GROUPS[prop.group]):
                rent *= 2
            incomes[owner] += chance * rent
        for i in survivors:
            others = sum(incomes[j] for j in survivors if j != i)
            net_rent = ((len(survivors) - 1) * incomes[i] - others) * remaining / len(survivors)
            worth[i] += net_rent + SET_BONUS * len(completed_sets(view.owners, i))
            worth[i] += CAPITAL_HURDLE * view.players[i].cash
        return worth[player] - max(worth[i] for i in survivors if i != player)


class MCTSDecisions:
    def buy(self, view: GameView, player: int, square: int) -> bool:
        # Compare buying vs skipping using simulations
        pass

    def build(self, view: GameView, player: int, legal: tuple[int, ...]) -> int | None:
        # Run simulations to choose a building
        pass


class ProspectTheoryDecisions:
    def buy(self, view: GameView, player: int, square: int) -> bool:
        # Evaluate potential gains and losses
        pass

    def build(self, view: GameView, player: int, legal: tuple[int, ...]) -> int | None:
        # Choose a building based on risk-sensitive utility
        pass